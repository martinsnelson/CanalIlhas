#!/usr/bin/env bash

brew update
brew install openssl nginx
