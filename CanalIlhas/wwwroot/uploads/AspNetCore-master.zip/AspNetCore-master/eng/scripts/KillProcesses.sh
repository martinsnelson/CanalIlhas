#!/usr/bin/env bash

pkill dotnet || true
exit 0
