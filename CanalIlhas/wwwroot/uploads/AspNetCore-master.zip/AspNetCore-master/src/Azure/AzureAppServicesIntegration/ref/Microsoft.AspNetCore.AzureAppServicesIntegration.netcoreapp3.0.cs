// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

namespace Microsoft.AspNetCore.Hosting
{
    public static partial class AppServicesWebHostBuilderExtensions
    {
        public static Microsoft.AspNetCore.Hosting.IWebHostBuilder UseAzureAppServices(this Microsoft.AspNetCore.Hosting.IWebHostBuilder hostBuilder) { throw null; }
    }
}
