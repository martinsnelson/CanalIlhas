using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AzureADSample.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
